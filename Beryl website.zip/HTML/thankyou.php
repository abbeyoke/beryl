<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="favicon.png">

    <title>Thank You: Beryl Consulting Limited</title>
    
    <link href="bootstrap3/css/bootstrap.css" rel="stylesheet">

    <!-- main css -->
    <link href="css/main.css" rel="stylesheet">
    
    <!-- mobile css -->
    <link href="css/responsive.css" rel="stylesheet">
    
    <!-- FontAwesome Support -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <!-- FontAwesome Support -->
    
    <!-- Btns -->
    <link rel="stylesheet" type="text/css" href="css/btn.css" />
    <!-- Btns -->
    
    <!-- Superfish menu -->
    <link rel="stylesheet" type="text/css" href="css/superfish/superfish.css" />
    <!-- Superfish menu -->
    
    <!-- Theme Color selector -->
    <link href="js/theme-color-selector/theme-color-selector.css" type="text/css" rel="stylesheet">
    <!-- Theme Color selector -->
    
    <!-- Iris Color selector -->
    <link href="js/iris/iris.min.css" type="text/css" rel="stylesheet">
    <!-- Iris Color selector -->
    
    <!-- Owl Carousel -->
    <link rel="stylesheet" type="text/css" href="js/owl-carousel/owl.carousel.css" />
    <!-- Owl Carousel -->
    
    <!-- Twitter feed -->
    <link rel="stylesheet" type="text/css" href="css/twitterfeed.css" />
    <!-- Twitter feed -->
    
    <!-- Typicons -->
    <link rel="stylesheet" type="text/css" href="css/typicons/typicons.min.css" />
    <!-- Typicons -->
    
    <!-- WOW animations -->
    <link rel="stylesheet" type="text/css" href="js/wow/css/libs/animate.css" />
    <!-- WOW animations -->
    
    <!-- Forms -->
    <link rel="stylesheet" type="text/css" href="css/forms.css" />
    <!-- Forms -->
        
    <!-- Development Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700italic,700,800,800italic%7CLato:400,100italic,100,300,300italic,400italic,700,700italic,900,900italic%7CRoboto:400,100,100italic,300,300italic,400italic,500,700,500italic,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <!-- Development Google Fonts -->
    
  </head>

  <body>
  
  <!-- Theme color selector -->
  <!--<div id="pm_theme_color_selector">
        <a class="pm_theme_color_selector_btn"><i class="typcn typcn-cog"></i></a>
        <p class="pm_theme_color_selector_title">Style Sampler</p>

        <div class="pm_theme_color_selector_container">
        	<p>Layout Style</p>
        	<select name="pm_theme_color_selector_mode" id="pm_theme_color_selector_mode">
        	  <option value="pm-full-mode" selected>Fullscreen</option>
              <option value="pm-boxed-mode">Boxed Mode</option>
        	</select>
        </div>
        <div class="pm_theme_color_selector_container">
        	<p>Patterns for Boxed Mode</p>
        	<ul class="pm_theme_img_selector" id="pm_theme_pattern_selector">
                <li><a href="#" id="01_pattern"><img src="img/boxed-patterns/01_pattern.png" alt="pattern1"></a></li>
                <li><a href="#" id="02_pattern"><img src="img/boxed-patterns/02_pattern.png" alt="pattern2"></a></li>
                <li><a href="#" id="03_pattern"><img src="img/boxed-patterns/03_pattern.png" alt="pattern3"></a></li>
                <li><a href="#" id="04_pattern"><img src="img/boxed-patterns/04_pattern.png" alt="pattern4"></a></li>
                <li><a href="#" id="05_pattern"><img src="img/boxed-patterns/05_pattern.png" alt="pattern5"></a></li>
                <li><a href="#" id="06_pattern"><img src="img/boxed-patterns/06_pattern.png" alt="pattern6"></a></li>
            </ul>
        </div>
        
        <div class="pm_theme_color_selector_container">
        	<p>Backgrounds for Boxed Mode</p>
        	<ul class="pm_theme_img_selector" id="pm_theme_background_selector">
                <li><a href="#" id="01_bg"><img src="img/boxed-bgs/01_bg_thumb.jpg" alt="bg1"></a></li>
                <li><a href="#" id="02_bg"><img src="img/boxed-bgs/02_bg_thumb.jpg" alt="bg2"></a></li>
                <li><a href="#" id="03_bg"><img src="img/boxed-bgs/03_bg_thumb.jpg" alt="bg3"></a></li>
                <li><a href="#" id="04_bg"><img src="img/boxed-bgs/04_bg_thumb.jpg" alt="bg4"></a></li>
                <li><a href="#" id="05_bg"><img src="img/boxed-bgs/05_bg_thumb.jpg" alt="bg5"></a></li>
            </ul>
        </div>
   
    </div>
    <!-- Theme color selector -->
    
    <!-- Search container -->
    <div class="pm-search-container" id="pm-search-container">
        <!-- Search window -->
        <div class="pm-search-columns">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 pm-center">
                        <p>Search News Posts</p>
                    </div>          
                </div>
                <div class="row">
                    <div class="col-lg-12">                       
                        <div class="pm-search-box">
                           <i class="fa-search pm-search-submit" id="pm-search-submit"></i>
                            <form name="searchform" id="pm-searchform" method="get" action="#">
                                <input type="text" name="s" placeholder="Type Keywords...">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="row">                    
                    <div class="col-lg-12">
                        <i class="fa fa-times pm-search-exit" id="pm-search-exit"></i>
                    </div>
                </div>
            </div>
        </div>
        <!-- Search window end -->  
    </div>
    <!-- Search container end -->

	<div id="pm_layout_wrapper" class="pm-full-mode"><!-- Use wrapper for wide or boxed mode -->
    
    	<div class="pm-header-info">
        
        	<div class="container pm-header-info-container">
                
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <ul class="pm-header-support-ul">
                            <li>
                                <p class="pm-header-support-text">General Inquiries <span>080-5531-9068</span></p>
                            </li>
                            <li class="pm-header-support-text-bullet"><p class="pm-header-support-text">&bull;</p></li>
                            <li>
                                <p class="pm-header-support-text">Support <span>070-8820-7020</span></p>
                            </li>
                        </ul>
                        
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="pm-header-buttons-spacer">
                        
                            <ul class="pm-header-buttons-ul">
                                <li>
                                    <p class="pm-header-login-text">Get started today!</p>
                                </li>
                                <li>
                                    <div class="pm-base-btn pm-header-btn pm-register-btn">
                                        <a href="registration.html">Register</a>
                                    </div>
                                </li>
                               <!-- <li>
                                    <div class="pm-base-btn pm-header-btn pm-login-btn">
                                        <a href="login.html">Login</a>
                                    </div>
                                </li>-->
                                <li>
                                    <div class="pm-base-btn pm-header-btn search" id="pm-search-btn">
                                        <a class="fa fa-search"></a>
                                    </div>
                                </li>
                            </ul>
                            
                        </div>
                        
                    </div>
                </div>
                
            </div>
            
        </div><!-- /pm-header-info -->
    
    	<header>
                
        	<div class="container pm-header-container">
                <div class="row">
                
                    <div class="col-lg-4 col-md-3 col-sm-12 pm-header-logo-div">
                    	<div class="pm-header-logo-container">
                        	<a href="index.html"><img src="img/beryl-logo.png" class="img-responsive" alt="Homepage"></a>
                        </div>
                    	
                        <div class="pm-header-mobile-btn-container">
                        	<button type="button" class="navbar-toggle pm-main-menu-btn" id="pm-main-menu-btn" data-toggle="collapse" data-target=".navbar-collapse"><i class="fa fa-bars"></i></button>
                        </div>
                        
                    </div>
                                                            
                    <div class="col-lg-8 col-md-9 col-sm-12 pm-main-menu">
                                            
                        <nav class="navbar-collapse collapse">
                        	
                            <!-- superfish-->
                            <ul class="sf-menu" id="pm-nav">
                                <li class="current">
                                    <a href="index.html">Home</a>
                                  </li>
                                
                               
                                <li>
                                    <a href="about.html">About Us</a>
                                    
                                </li>
                      
                               
                                <li>
                                    <a href="services.html">Services</a>
                                <ul>
                                        <li>
                                            <a href="managementservice.html">Management Consulting</a>
                                        </li>
                                        <li>
                                            <a href="technologyservice.html">Technology Consulting</a>
                                        </li>
                                        <li>
                                            <a href="trainingservice.html">Training</a>
                                        </li>
                                        <li>
                                            <a href="pmservice.html">Project Management</a>
                                        </li>
                                    </ul>
                                </li>
                                
                               
                                <li>
                                    <a href="trainingall.html">Training Calendar</a>
                                </li>
                               
                               
                                <li>
                                    <a href="contact.html">Contact Us</a>
                                </li>
                            </ul>
                            <!-- /superfish -->
                            
                        </nav> 
                        
                    </div>
                                        
                </div>       
                
            </div>
                    
        </header><!-- /header -->
                
        <!-- SUBHEADER AREA -->
        
        <div class="pm-sub-header-container pm-parallax-panel" data-stellar-background-ratio="0.5" data-stellar-vertical-offset="95">
        	
            <div class="pm-sub-header-breadcrumbs">
            	<ul class="pm-sub-header-breadcrumbs-ul">
                	<li><a href="#">Home</a></li>
                    <li><i class="fa fa-angle-right"></i></li>
                    <li class="current">Thank You</li>
                </ul>
            </div>
            
            <div class="pm-sub-header-title-container">
            	<h5>Thank You</h5>
            </div>
            
            <div class="pm-sub-header-message">
            	<p>You message was successfully delivered!!! Please allow up to 48hours to hear from us.</p>
            </div>
                        
        </div>
        
 		<!-- SUBHEADER AREA end -->
        
        <!-- BODY AREA -->
        
        <div class="container pm-containerPadding-top-60 pm-containerPadding-bottom-30">
        	<div class="row">
                <div class="col-lg-12">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2886.610286532898!2d-79.38211079999994!3d43.65627589999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34ca4e2d4c49%3A0x2f3acf786271e874!2s1+Dundas+St+W%2C+Toronto%2C+ON+M5G+1Z1!5e0!3m2!1sen!2sca!4v1405449927496" width="320" height="260" style="border:4px solid #e3e3e3;"></iframe>
                </div>
            </div>
        </div>
        
        <div class="container pm-containerPadding-bottom-40">
        	<div class="row">
            	
                <div class="col-lg-6 col-md-6 col-sm-6">
                	<h5 class="pm-primary">Reach us by email or phone</h5>
                    <p><strong>General Inquiries:</strong> 080-5531-9068</p>
                    <p><strong>Support Line:</strong> 070-8820-7020</p>
                    <p><strong>Email:</strong> <a href="mailto:info@berylconsultinglimited.com">info@berylconsultinglimited.com</a></p>
                </div>
                
                <div class="col-lg-6 col-md-6 col-sm-6">
                	<h5 class="pm-primary">Our Location</h5>
                    <p class="pm-no-margin">13a, Alhaji Jimoh Street,</p>
                    <p class="pm-no-margin">Ikeja, Lagos</p>
                    <p class="pm-no-margin">Nigeria.</p>
                </div>
                
            </div>
        </div>
        
        <div class="container pm-containerPadding-bottom-60">
        	<div class="row">
            	<div class="col-lg-12">
                	<h5 class="pm-primary">Send us an inquiry</h5>
                    <div class="pm-contact-form-container">
                    	<p class="pm-required">Your email address will be held strictly confidential. Required fields are marked *</p>
                    	<p align="justify">One of our representatives will get in touch with you shortly.</p>
                    	
                    	
                    	
                    	<form id="contact-form" action="contact-form.php" method="post" accept-charset="utf-8">

                            <input name="full_name" id="full_name" type="text" placeholder="Name *" class="pm-form-textfield">
                            <input name="email_address" id="email_address" type="text" placeholder="Email *" class="pm-form-textfield">
                            <input name="subject" id="subject" type="text" placeholder="Subject *" class="pm-form-textfield">
                            <textarea name="message" id="message" cols="20" rows="6" placeholder="Inquiry *" class="pm-form-textarea"></textarea>
                            <div class="pm_captcha_box">
                            	<p>Security Code:</p>
                                <img src="js/ajax-contact/CaptchaSecurityImages.php?width=100&height=40&characters=5" /><br />
                                <div style="width:96px;">
                                    <div style="padding-top:2px; width:86px;">
                                    	<input class="pm_s_security_code pm-form-textfield" name="security_code" type="text" class="form_field_security" id="security_code" maxlength="5" />
                                    </div>
                                </div>
                            </div>
                            <div id="pm-contact-form-response"></div>
                            <input name="pm-form-submit-btn" class="pm-rounded-submit-btn" type="button" value="Submit" id="pm-contact-form-btn" />
                            <input type="hidden" value="pm-contact-form-submitted" />
                            <input type="hidden" name="pm_s_email_address_contact" value="leo@pulsarmedia.ca" />
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- BODY AREA end -->
        
      <div class="pm-fat-footer">
        	
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-12 pm-widget-footer">
                      <img src="img/beryl-logo-footer.png" width="220" height="45">
                      <p align="justify">Beryl Consulting Limited is primarily active in the field of Business and technology Consulting, Training and end to end business solutions with emphasis on Performance Management and Information Technology.</p>
                  </div>
                    <div class="col-lg-3 col-md-6 col-sm-12 pm-widget-footer">
                        <h6>career openings <i class="fa fa-users"></i></h6>
                        
                        <ul class="pm-career-opening-widget-posts">
                            <!-- post -->
                            <li class="pm-career-opening-widget-post">
                                <i class="fa fa-laptop"></i>
                                <div class="pm-career-opening-widget-post-info">
                                    <p>Software Developer</p>
                                    <a href="careers.html">Read More <i class="fa fa-angle-right"></i></a>
                                </div>
                            </li>
                            <!-- /post -->
                            <!-- post -->
                            <li class="pm-career-opening-widget-post">
                                <i class="fa fa-mobile"></i>
                                <div class="pm-career-opening-widget-post-info">
                                    <p>Mobile app developer</p>
                                    <a href="careers.html">Read More <i class="fa fa-angle-right"></i></a>
                                </div>
                            </li>
                            <!-- /post -->
                            <!-- post -->
                            <li class="pm-career-opening-widget-post">
                                <i class="fa fa-pencil"></i>
                                <div class="pm-career-opening-widget-post-info">
                                    <p>Business Analyst</p>
                                    <a href="careers.html">Read More <i class="fa fa-angle-right"></i></a>
                                </div>
                            </li>
                            <!-- /post -->
                            <!-- post -->
                         <!--   <li class="pm-career-opening-widget-post">
                                <i class="fa fa-pencil"></i>
                                <div class="pm-career-opening-widget-post-info">
                                    <p>User Interface Designer</p>
                                    <a href="careers-single-post.html">Read More <i class="fa fa-angle-right"></i></a>
                                </div>
                            </li>
                            <!-- /post -->
                        </ul>
                        
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12 pm-widget-footer">
                        <h6>upcoming workshops <i class="fa fa-gears"></i></h6>
                        
                        <ul class="pm-workshop-widget-posts">
                            <!-- post -->
                            <li class="pm-workshop-widget-post">
                                <i class="fa fa-laptop"></i>
                                <div class="pm-workshop-widget-post-info">
                                    <a href="mssharepoint2010.html">Microsoft Sharepoint 2010</a>
                                    <p>Mar 23 | 9:00am.</p>
                                </div>
                            </li>
                            <!-- /post -->
                            <!-- post -->
                            <li class="pm-workshop-widget-post">
                                <i class="fa fa-rocket"></i>
                                <div class="pm-workshop-widget-post-info">
                                    <a href="projectmanagement.html">Project Management</a>
                                    <p>Apr 06 | 9:00am.</p>
                                </div>
                            </li>
                            <!-- /post -->
                            <!-- post -->
                            <li class="pm-workshop-widget-post">
                                <i class="fa fa-bolt"></i>
                                <div class="pm-workshop-widget-post-info">
                                    <a href="sapfi.html">SAP Finance (SAP FI)</a>
                                    <p>Apr 20 | 9:30am.</p>
                                </div>
                            </li>
                            <!-- /post -->
                        </ul>
                        
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12 pm-widget-footer">
                        <h6>latest tweets <i class="fa fa-twitter"></i></h6>
                        
                        <ul class="tweet_list">
                        
                            <li class="tweet_first">
                                <div class="tweet_container">
                                    <span class="tweet_time"><a title="view tweet on twitter" href="#">about 14 days ago</a></span>
                                    <span class="tweet_join"></span>
                                    <span class="tweet_text">Check out new training facility<span class="at">@</span><a href="#">Beryl</a> : "The Learning Center" <a href="#">bit.ly/1szLobl</a></span>
                                </div>
                            </li>
                            
                            <li class="tweet_first">
                                <div class="tweet_container">
                                    <span class="tweet_time"><a title="view tweet on twitter" href="#">about 21 days ago</a></span>
                                    <span class="tweet_join"></span>
                                    <span class="tweet_text">Check out our new training calender <span class="at">@</span><a href="#">Beryl</a> trainings <a href="#">bit.ly/1szLobl</a></span>
                                </div>
                            </li>
                            
                        </ul>
                        
                    </div>
                </div>	
            </div>
            
        </div>
        
        <footer>
        
        	<div class="container">
                <div class="row">
                    
                   <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="pm-footer-social-info-container">
                            <h6>Join the conversation</h6>
                            <p>Follow us on social media for special announcments and upcoming events.</p>
                            <ul class="pm-footer-social-icons">
                                <li title="Twitter" class="pm_tip_static_top"><a href="#"><i class="fa fa-twitter tw"></i></a></li>
                                <li title="Facebook" class="pm_tip_static_top"><a href="#"><i class="fa fa-facebook fb"></i></a></li>
                                <li title="Google Plus" class="pm_tip_static_top"><a href="#"><i class="fa fa-google-plus gp"></i></a></li>
                                <li title="Linkedin" class="pm_tip_static_top"><a href="#"><i class="fa fa-linkedin linked"></i></a></li>
                                <li title="YouTube" class="pm_tip_static_top"><a href="#"><i class="fa fa-youtube yt"></i></a></li>
                            </ul>
                        </div>
                        
                   </div>
                   
                   <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="pm-footer-subscribe-container">
                            <h6>Subscribe to our newsletter</h6>
                            <p>Sign up for our weekly newsletter and stay up to date with Beryl Consulting Limited.</p>
                            <div class="pm-footer-subscribe-form-container">
                                <form action="#" method="post" id="pm-footer-subscribe">
                                    <input class="pm-footer-subscribe-field" type="text" placeholder="Email Address" value="" />
                                    <div class="pm-footer-subscribe-submit-btn">
                                        <i class="fa fa-paper-plane"></i>
                                    </div>
                                </form>
                            </div>
                        </div>
                   </div>
                    
                </div>
            </div>	

                
        </footer>
                
        <div class="pm-footer-copyright">
        	
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-5 col-sm-12 pm-footer-copyright-col">
                        <p>&copy; 2014 <a href="http://www.berylconsultinglimited.com" target="_blank">Beryl Consulting Limited</a></p>
                    </div>
                    <div class="col-lg-7 col-md-7 col-sm-12 pm-footer-navigation-col">
                        <ul class="pm-footer-navigation" id="pm-footer-nav">
                            <li><a href="services.html">Our Services</a></li>
                            <!--<li><a href="workshops.html">Workshops</a></li>-->
                            <li><a href="about.html">About Us</a></li>
                            <!--<li><a href="who-we-are.html">Who we are</a></li>-->
                            <li><a href="trainingall.html">Training Calendar</a></li>
                           <!-- <li><a href="blog.html">blog</a></li>-->
                            <li><a href="contact.html">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
        </div>
    
    </div><!-- /pm_layout-wrapper -->
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-2.1.1.min.js"></script>
    <script src="js/jquery.viewport.mini.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="bootstrap3/js/bootstrap.min.js"></script>
    <script src="js/modernizr.custom.js"></script>
    <script src="js/owl-carousel/owl.carousel.js"></script>
    <script src="js/main.js"></script>
    <script src="js/jquery.tooltip.js"></script>
    <script src="js/jquery.hoverPanel.js"></script>
    <script src="js/superfish/superfish.js"></script>
    <script src="js/superfish/hoverIntent.js"></script>
    <script src="js/tinynav.js"></script>
    <script src="js/stellar/jquery.stellar.js"></script>
    <script src="js/countdown/countdown.js"></script>
    <script src="js/theme-color-selector/theme-color-selector.js"></script>
	<script src="js/wow/wow.min.js"></script>
    <script src="js/ajax-contact/ajax-email.js"></script>
        
    <p id="back-top" class="visible-lg visible-md visible-sm"> </p>
    
  </body>
</html>
